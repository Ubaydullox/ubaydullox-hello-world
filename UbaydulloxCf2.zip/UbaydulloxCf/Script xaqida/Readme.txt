Assalom - Alekum xurmatli script foydalanuvchisi !!!

Ushbu script @Ibragimov_Ubaydullox ga tegishli
ushbu script xvest xostingiga qo'yilgan va freenom dan domen olingan !!

! Diqqat ushbu scriptni fayl va paplalar nomini o'zgartirmang agar o'zgartirsangiz kod ishdan chiqadi. !

Ushbu scriptni o'zingizga moslab olishingiz mumkun )
